package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class OrderDAL {
	@Autowired
	JdbcTemplate jdbcTemplate;
	void persist(Order order){
		jdbcTemplate.execute("INSERT INTO fmr.order (price, company) values("+order.getPrice()
		+",'"+order.company+"')");
	}
	public void delete(int orderId) {
		jdbcTemplate.execute("DELETE FROM fmr.ORDER WHERE ID="+orderId);
	}
}

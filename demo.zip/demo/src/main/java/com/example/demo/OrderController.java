package com.example.demo;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController //
public class OrderController {
	@GetMapping("/order/{id}/{country}" ) //url+method
	String get(@PathParam("age") int age, @PathParam("param1") String param1, 
			@PathParam("salary") float salary, @PathVariable("id") int id,
			@PathVariable("country") String country){
		System.out.println(age);
		System.out.println(id);
		System.out.println(country);
		return "hello world"+param1+salary*0.9;
	}
	
	@PostMapping("/order" ) //url+method
	String post(){
		return "hello world -post";
	}
}

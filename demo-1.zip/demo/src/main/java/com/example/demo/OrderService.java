package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component //mark a class as spring bean
public class OrderService {
	@Autowired //to achieve DI
	public OrderDAL orderDAL;
	public void save() {

	}
}

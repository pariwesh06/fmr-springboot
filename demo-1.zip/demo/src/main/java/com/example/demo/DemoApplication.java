package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(DemoApplication.class, args);
//		OrderService orderService = context.getBean(OrderService.class);
//		OrderDAL orderDAL = context.getBean(OrderDAL.class);
//		OrderDAL orderDAL1 = context.getBean(OrderDAL.class);
//		System.out.println(orderDAL== orderDAL1);
////		OrderService service= new OrderService();
//		System.out.println(orderService.orderDAL == orderDAL);
//		orderService.save();
	}
}

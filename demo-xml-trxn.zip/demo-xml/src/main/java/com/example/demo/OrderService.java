package com.example.demo;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component //mark a class as spring bean
public class OrderService {
	@Autowired //to achieve DI
	public OrderDAL orderDAL;
	public void save(Order order) throws Exception {
		orderDAL.persist(order);
		
	}
	public void delete(int orderId) {
		orderDAL.delete(orderId);
	}
	public List<Order> getOrder() {
		List<Order> orders=null;
//		try {
			orders = orderDAL.getOrders();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		}
//		writeFile(orders);
		return orders;
	}
	private void writeFile(List<Order> orders) {
		try {
			FileWriter writer= new FileWriter("output.json");
			writer.write(orders.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}

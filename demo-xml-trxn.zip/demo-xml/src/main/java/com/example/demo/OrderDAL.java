package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class OrderDAL {
	@Autowired
	JdbcTemplate jdbcTemplate;

	void persist(Order order) throws Exception {
		jdbcTemplate.execute(
				"INSERT INTO fmr.order (price, company) values(" + order.getPrice() + ",'" + order.company + "')");
		int a = 1 / 0;
		// try {
		// throw new Exception();
		// } catch (Exception e) {
		// e.printStackTrace();
		// }
	}

	public void delete(int orderId) {
		jdbcTemplate.execute("DELETE FROM fmr.ORDER WHERE ID=" + orderId);
	}

	public List<Order> getOrders() {
		String queryString = "SELECT * from fmr.ORDER";
		List<Order> orders = jdbcTemplate.query(queryString, new RowMapper() {
			@Override
			public Object mapRow(ResultSet resultSet, int index) throws SQLException {
				Order order = new Order();
				order.company = resultSet.getString("company");
				order.price = resultSet.getInt("price");
				return order;
			}
		});
		return orders;
	}
}

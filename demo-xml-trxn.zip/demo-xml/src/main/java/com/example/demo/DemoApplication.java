package com.example.demo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
@ImportResource("application-context.xml")
public class DemoApplication {
	@Value ("${dburl}")
	String dbUrl;
	@Bean
	PlatformTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource());
	}
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(DemoApplication.class, args);
//		OrderService orderService = context.getBean(OrderService.class);
//		OrderDAL orderDAL = context.getBean(OrderDAL.class);
//		OrderDAL orderDAL1 = context.getBean(OrderDAL.class);
//		System.out.println(orderDAL== orderDAL1);
////		OrderService service= new OrderService();
//		System.out.println(orderService.orderDAL == orderDAL);
//		orderService.save();
	}
	@Bean
	DataSource dataSource() {//    jdbc:oracle:thin:@//vlascrdurtp1:1521/oerpuat
		System.out.println(dbUrl);
		return new DriverManagerDataSource(dbUrl,
				"root", "");
	}
	
	@Bean
	JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(dataSource());
	}
}

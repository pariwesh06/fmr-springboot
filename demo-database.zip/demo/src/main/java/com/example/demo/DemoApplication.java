package com.example.demo;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(DemoApplication.class, args);
//		OrderService orderService = context.getBean(OrderService.class);
//		OrderDAL orderDAL = context.getBean(OrderDAL.class);
//		OrderDAL orderDAL1 = context.getBean(OrderDAL.class);
//		System.out.println(orderDAL== orderDAL1);
////		OrderService service= new OrderService();
//		System.out.println(orderService.orderDAL == orderDAL);
//		orderService.save();
	}
	@Bean
	DataSource dataSource() {//    jdbc:oracle:thin:@//vlascrdurtp1:1521/oerpuat
		return new DriverManagerDataSource("jdbc:mysql://localhost:3306/fmr",
				"root", "");
	}
	@Bean
	JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(dataSource());
	}
}

package com.example.demo;

import java.util.Arrays;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController //
public class OrderController {
	@Autowired
	OrderService orderService;
	@PostMapping("/order")
	void saveOrder(){
		orderService.save();
	}
	@GetMapping("/order/{id}/{country}") // url+method
	String get(@PathParam("age") int age, @PathParam("param1") String param1, @PathParam("salary") float salary,
			@PathVariable("id") int id, @PathVariable("country") String country) {
		System.out.println(age);
		System.out.println(id);
		System.out.println(country);
		return "hello world" + param1 + salary * 0.9;
	}

	// @PutMapping("/order" )
	// @PostMapping("/order" ) //url+method
	@RequestMapping(value = "/order", method = { RequestMethod.PUT })
	OrderSummary post( @PathParam("state") String selectedState, @RequestBody Order[] order) {
		int totalPrice = 0;
		int totalItems = 0;
		for (int i = 0; i < order.length; i++) {
			if(selectedState.equalsIgnoreCase(order[i].state)) {
				totalPrice = totalPrice + order[i].price;
				totalItems = totalItems+ order[i].getItems().length;
			}
			// System.out.println(Arrays.toString(order[i].getItems()));
		}
		OrderSummary orderSummary=new OrderSummary();
		orderSummary.setTotalPrice(totalPrice);
		orderSummary.setTotalItems(totalItems);
		return orderSummary;
	}
	
}

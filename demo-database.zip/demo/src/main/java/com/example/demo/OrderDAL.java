package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class OrderDAL {
	@Autowired
	JdbcTemplate jdbcTemplate;
	void persist(){
		jdbcTemplate.execute("INSERT INTO fmr.order (price, company) values(200, 'FIDELITY')");
	}
}
